package view;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import javax.imageio.ImageIO;

/**
 * Il pannello di gioco visualizza il giocatore, gli ostacoli e il punteggio.
 * @author Candoni Zanatta Bergamo
 */
public class Pannello extends JPanel {
	/**
	 * Dimensione del giocatore
	 */
    private static final int PLAYER_SIZE = 60; 
    /**
     * Incremento del punteggio
     */
    private static final int SCORE_INCREMENT = 10;
    /**
     * Posizione X del giocatore
     */
    private int playerX;
    /**
     * Posizione Y del giocatore
     */
    private int playerY; 
    /**
     * Punteggio iniziale
     */
    private int score = 0; 
    /**
     * Immagine del giocatore
     */
    private BufferedImage playerImage; 
    /**
     * Lista degli ostacoli
     */
    private ArrayList<Rectangle> obstacles; 
    /**
     * Lista delle icone degli ostacoli
     */
    private ArrayList<ImageIcon> obstacleIcons; 
    /**
     * Timer per l'incremento del punteggio
     */
    private Timer scoreTimer; 

    /**
     * Costruisce un nuovo pannello di gioco.
     */
    public Pannello() {
        setFocusable(true);
        requestFocus();
        obstacleIcons = new ArrayList<>();
        loadPlayerImage(); // Carica l'immagine del giocatore

        // Inizializzazione del timer per l'incremento del punteggio
        scoreTimer = new Timer(2000, e -> {
            score += SCORE_INCREMENT; // Incrementa il punteggio
            repaint(); // Ridisegna il pannello per mostrare il nuovo punteggio
        });
        scoreTimer.start(); // Avvia il timer
    }

    private void loadPlayerImage() {
        try {
            URL imageURL = getClass().getResource("/view/utente.png");
            if (imageURL != null) {
                playerImage = ImageIO.read(imageURL); // Carica l'immagine del giocatore
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Imposta la posizione del giocatore.
     * 
     * @param x La coordinata X del giocatore
     * @param y La coordinata Y del giocatore
     */
    public void setPlayerPosition(int x, int y) {
        this.playerX = x;
        this.playerY = y;
    }

    /**
     * Restituisce la coordinata X del giocatore.
     * 
     * @return La coordinata X del giocatore
     */
    public int getPlayerX() {
        return playerX;
    }

    /**
     * Restituisce la coordinata Y del giocatore.
     * 
     * @return La coordinata Y del giocatore
     */
    public int getPlayerY() {
        return playerY;
    }

    /**
     * Restituisce il punteggio attuale.
     * 
     * @return Il punteggio attuale
     */
    public int getScore() {
        return score;
    }

    /**
     * Restituisce la dimensione del giocatore.
     * 
     * @return La dimensione del giocatore
     */
    public int getPLAYER_SIZE() {
        return PLAYER_SIZE;
    }

    /**
     * Imposta gli ostacoli da disegnare nel pannello.
     * 
     * @param obstacles Lista degli ostacoli
     * @param obstacleIcons Lista delle icone degli ostacoli
     */
    public void setObstacles(ArrayList<Rectangle> obstacles, ArrayList<ImageIcon> obstacleIcons) {
        this.obstacles = obstacles;
        this.obstacleIcons = obstacleIcons;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight()); // Riempie il pannello con il colore di sfondo

        if (playerImage != null) {
            g.drawImage(playerImage, playerX, playerY, PLAYER_SIZE, PLAYER_SIZE, this); // Disegna il giocatore
        }

        if (obstacles != null) {
            for (int i = 0; i < obstacles.size(); i++) {
                Rectangle obstacle = obstacles.get(i);
                ImageIcon obstacleIcon = obstacleIcons.get(i);
                obstacleIcon.paintIcon(this, g, obstacle.x, obstacle.y); // Disegna gli ostacoli
            }
        }

        // Disegna il punteggio
        g.setColor(Color.WHITE);
        g.drawString("Punteggio: " + score, 10, 20);
    }
}
