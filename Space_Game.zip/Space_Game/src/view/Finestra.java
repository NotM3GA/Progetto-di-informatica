package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * La classe Finestra rappresenta la finestra principale del gioco.
 * @author Candoni Zanatta Bergamo
 */
public class Finestra extends JFrame {

    private static final long serialVersionUID = 1L;
    /**
     * dichiarazione dell'istanza del pannello
     */
    private Pannello contentPane;

    /**
     * Crea una nuova finestra di gioco.
     */
    public Finestra() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Chiude l'applicazione quando la finestra viene chiusa
        setBounds(100, 100, 800, 600); // Imposta le dimensioni della finestra
        setTitle("Space Game"); // Imposta il titolo della finestra
        contentPane = new Pannello(); // Crea un nuovo pannello di gioco
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5)); // Imposta il bordo vuoto intorno al pannello
        setContentPane(contentPane); // Imposta il pannello come contenuto della finestra
        setVisible(true); // Rende la finestra visibile

        ImageIcon icon = new ImageIcon("src/view/icon.png"); // Carica l'icona della finestra
        setIconImage(icon.getImage()); // Imposta l'icona della finestra
    }

    /**
     * Restituisce il pannello di gioco associato alla finestra.
     * 
     * @return Il pannello di gioco
     */
    public Pannello getPannello() {
        return contentPane;
    }
}
