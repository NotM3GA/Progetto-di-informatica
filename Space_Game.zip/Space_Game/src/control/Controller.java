package control;

import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import Model.SpaceModel;
import view.Pannello;

/**
 * La classe Controller gestisce l'input del giocatore e coordina il movimento nel gioco.
 * @author Candoni Zanatta Bergamo
 */
public class Controller implements KeyListener {
    private SpaceModel model; // Modello del gioco
    private Pannello view; // Vista del gioco
    private Timer autoMoveTimer; // Timer per il movimento automatico del giocatore
    private GameOverFrame gameOverFrame; // Frame di sconfitta

    /**
     * Costruisce un nuovo oggetto Controller dove vengono gestite le situazioni del gioco.
     * 
     * @param model Il modello del gioco
     * @param view La vista del gioco
     */
    public Controller(SpaceModel model, Pannello view) {
        this.model = model;
        this.view = view;
        view.setFocusable(true);
        view.requestFocus();
        view.addKeyListener(this);

        // Inizializza il timer per il movimento automatico del giocatore
        autoMoveTimer = new Timer(100, (e) -> movePlayer(view.getPlayerX(), view.getPlayerY() + 10, view.getPLAYER_SIZE()));
        autoMoveTimer.start(); // Avvia il timer
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        int playerX = view.getPlayerX();
        int playerY = view.getPlayerY();
        int PLAYER_SIZE = view.getPLAYER_SIZE();
        int WIDTH = view.getWidth();

        if (keyCode == KeyEvent.VK_LEFT) {
            movePlayer(playerX - 10, playerY, PLAYER_SIZE);
        } else if (keyCode == KeyEvent.VK_RIGHT) {
            movePlayer(playerX + 10, playerY, PLAYER_SIZE);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}

    /**
     * Muove il giocatore nelle nuove coordinate specificate.
     * 
     * @param newX La nuova coordinata X del giocatore
     * @param newY La nuova coordinata Y del giocatore
     * @param PLAYER_SIZE La dimensione del giocatore
     */
    private void movePlayer(int newX, int newY, int PLAYER_SIZE) {
        Rectangle newPlayerRect = new Rectangle(newX, newY, PLAYER_SIZE, PLAYER_SIZE);
        boolean collisionDetected = false; // Flag per indicare se è stata rilevata una collisione

        // Verifica la collisione con ciascun ostacolo
        for (Rectangle obstacle : model.getObstacles()) {
            if (newPlayerRect.intersects(obstacle)) {
                collisionDetected = true; // Imposta il flag su true se una collisione è stata rilevata
                handleCollisionWithObstacle(obstacle);
                break; // Esci dal ciclo quando una collisione è stata rilevata
            }
        }

        // Verifica se il nuovo movimento porta il giocatore fuori dai bordi della finestra
        if (!collisionDetected && newX >= 0 && newX <= view.getWidth() - PLAYER_SIZE && newY >= 0 && newY <= view.getHeight() - PLAYER_SIZE) {
            view.setPlayerPosition(newX, newY);
        }
    }

    /**
     * Gestisce la collisione con un ostacolo.
     * 
     * @param obstacle Il rettangolo dell'ostacolo con cui è avvenuta la collisione
     */
    private void handleCollisionWithObstacle(Rectangle obstacle) {
        System.out.println("Collisione con un ostacolo!");
        stopAutoMoveTimer(); // Interrompi il timer per il movimento automatico del giocatore
        showGameOverFrame(); // Visualizza il frame di sconfitta
    }

    /**
     * Interrompe il timer per il movimento automatico del giocatore.
     */
    private void stopAutoMoveTimer() {
        if (autoMoveTimer != null && autoMoveTimer.isRunning()) {
            autoMoveTimer.stop();
        }
    }

    /**
     * Visualizza il frame di sconfitta.
     */
    private void showGameOverFrame() {
        gameOverFrame = new GameOverFrame();
        
    }
}
