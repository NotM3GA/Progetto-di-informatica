package control;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * La classe GameOverFrame rappresenta il frame di sconfitta del gioco.
 * @author Candoni Zanatta Bergamo
 */
public class GameOverFrame extends JFrame {
	/**
	 * Dichiarazione della variabile di istanza gameOverFrame
	 */
    private JFrame gameOverFrame; 
    /**
     * Dichiarazione della variabile di istanza JLabel indica creatori
     */
    private JLabel lblNewLabel;  
    /**
     * Dichiarazione della variabile di istanza JLabel indica il nome del creatore
     */
    private JLabel lblNewLabel_1; 
    /**
     * Dichiarazione della variabile di istanza JLabel indica il nome del creatore
     */
    private JLabel lblNewLabel_2;
    /**
     * Dichiarazione della variabile di istanza JLabel indica il nome del creatore
     */
    private JLabel lblNewLabel_3;
    /**
     * Dichiarazione della variabile di istanza JLabel indica il nome del gioco
     */
    private JLabel lblNomeGioco;
    /**
     * Dichiarazione della variabile di istanza JLabel indica etichetta per l'icona
     */
    private JLabel lblNewLabel_4;
    /**
     * Dichiarazione della variabile di istanza JSeparator indica la divisione grafica dei contenuti
     */
    private JSeparator separator;
    /**
     * Dichiarazione della variabile di istanza JLabel indica etichetta per l'icona
     */
    private JLabel lblNewLabel_5; 

    /**
     * Crea un nuovo frame di sconfitta.
     */
    public GameOverFrame() {
    	getContentPane().setBackground(new Color(128, 128, 128)); // Imposta il colore di sfondo del contenuto
    	getContentPane().setForeground(new Color(128, 128, 128)); // Imposta il colore del testo del contenuto
        setTitle("Game Over"); // Imposta il titolo del frame
        setSize(568, 383); // Imposta le dimensioni del frame
        setBounds(100, 100, 800, 600); // Imposta la posizione e le dimensioni del frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Chiude l'applicazione quando il frame viene chiuso
        getContentPane().setLayout(null); // Imposta un layout nullo

        JLabel lblHaiPerso = new JLabel("Hai Perso!"); // Etichetta per indicare la sconfitta
        lblHaiPerso.setForeground(new Color(255, 0, 0)); // Imposta il colore del testo in rosso
        lblHaiPerso.setFont(new Font("Dubai", Font.BOLD, 30)); // Imposta il font e lo stile del testo
        lblHaiPerso.setBounds(10, 34, 766, 77); // Imposta le dimensioni e la posizione dell'etichetta
        lblHaiPerso.setHorizontalAlignment(JLabel.CENTER); // Imposta l'allineamento del testo al centro
        getContentPane().add(lblHaiPerso); // Aggiunge l'etichetta al contenuto del frame

        JButton exitButton = new JButton("Esci"); // Bottone per uscire dal gioco
        exitButton.setFont(new Font("Dubai", Font.BOLD, 20)); // Imposta il font e lo stile del testo del bottone
        exitButton.setBounds(232, 413, 329, 54); // Imposta le dimensioni e la posizione del bottone
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0); // Chiudi l'applicazione quando il bottone viene premuto
            }
        });
        getContentPane().add(exitButton); // Aggiunge il bottone al contenuto del frame
        
        lblNewLabel = new JLabel("CREATORI"); // Etichetta per indicare i creatori del gioco
        lblNewLabel.setForeground(new Color(255, 255, 255)); // Imposta il colore del testo in bianco
        lblNewLabel.setBackground(new Color(255, 255, 255)); // Imposta il colore di sfondo in bianco
        lblNewLabel.setFont(new Font("Dubai", Font.BOLD, 23)); // Imposta il font e lo stile del testo
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER); // Imposta l'allineamento del testo al centro
        lblNewLabel.setBounds(10, 270, 766, 27); // Imposta le dimensioni e la posizione dell'etichetta
        getContentPane().add(lblNewLabel); // Aggiunge l'etichetta al contenuto del frame
        
        lblNewLabel_1 = new JLabel("Zanatta Alberto"); // Etichetta per il nome del creatore
        lblNewLabel_1.setForeground(new Color(255, 255, 255)); // Imposta il colore del testo in bianco
        lblNewLabel_1.setFont(new Font("Dubai", Font.BOLD, 17)); // Imposta il font e lo stile del testo
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER); // Imposta l'allineamento del testo al centro
        lblNewLabel_1.setBounds(201, 321, 184, 25); // Imposta le dimensioni e la posizione dell'etichetta
        getContentPane().add(lblNewLabel_1); // Aggiunge l'etichetta al contenuto del frame
        
        lblNewLabel_2 = new JLabel("Bergamo Giovanni"); // Etichetta per il nome del creatore
        lblNewLabel_2.setForeground(new Color(255, 255, 255)); // Imposta il colore del testo in bianco
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER); // Imposta l'allineamento del testo al centro
        lblNewLabel_2.setFont(new Font("Dubai", Font.BOLD, 17)); // Imposta il font e lo stile del testo
        lblNewLabel_2.setBounds(300, 356, 184, 27); // Imposta le dimensioni e la posizione dell'etichetta
        getContentPane().add(lblNewLabel_2); // Aggiunge l'etichetta al contenuto del frame
        
        lblNewLabel_3 = new JLabel("Candoni Massimo"); // Etichetta per il nome del creatore
        lblNewLabel_3.setForeground(new Color(255, 255, 255)); // Imposta il colore del testo in bianco
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER); // Imposta l'allineamento del testo al centro
        lblNewLabel_3.setFont(new Font("Dubai", Font.BOLD, 17)); // Imposta il font e lo stile del testo
        lblNewLabel_3.setBounds(414, 321, 184, 25); // Imposta le dimensioni e la posizione dell'etichetta
        getContentPane().add(lblNewLabel_3); // Aggiunge l'etichetta al contenuto del frame
        
        lblNomeGioco = new JLabel("SPACE  GAME"); // Etichetta per il nome del gioco
        lblNomeGioco.setHorizontalAlignment(SwingConstants.CENTER); // Imposta l'allineamento del testo al centro
        lblNomeGioco.setForeground(Color.WHITE); // Imposta il colore del testo in bianco
        lblNomeGioco.setFont(new Font("Cambria", Font.BOLD, 35)); // Imposta il font e lo stile del testo
        lblNomeGioco.setBackground(Color.WHITE); // Imposta il colore di sfondo in bianco
        lblNomeGioco.setBounds(20, 171, 766, 27); // Imposta le dimensioni e la posizione dell'etichetta
        getContentPane().add(lblNomeGioco); // Aggiunge l'etichetta al contenuto del frame

        ImageIcon icon = new ImageIcon(GameOverFrame.class.getResource("/view/icon.png")); // Carica l'icona

        lblNewLabel_4 = new JLabel(icon); // Etichetta per l'icona
        lblNewLabel_4.setBounds(20, 10, 177, 205); // Imposta le dimensioni e la posizione dell'etichetta
        getContentPane().add(lblNewLabel_4); // Aggiunge l'etichetta al contenuto del frame
        
        separator = new JSeparator(); // Separatore
        separator.setBackground(new Color(255, 255, 255)); // Imposta il colore di sfondo del separatore in bianco
        separator.setBounds(147, 243, 502, 2); // Imposta le dimensioni e la posizione del separatore
        getContentPane().add(separator); // Aggiunge il separatore al contenuto del frame
        
        lblNewLabel_5 = new JLabel(icon); // Etichetta per l'icona
        lblNewLabel_5.setBounds(599, 10, 177, 205); // Imposta le dimensioni e la posizione dell'etichetta
        getContentPane().add(lblNewLabel_5); // Aggiunge l'etichetta al contenuto del frame
        setVisible(true); // Rende il frame visibile
    }
}
