package Model;

import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 * La classe SpaceModel rappresenta il modello per un gioco a tema spaziale.
 * Gestisce gli ostacoli all'interno dello spazio di gioco.
 * 
 * @author Candoni Zanatta Bergamo
 * @version 1.0
 */
public class SpaceModel {
	
    private static final int WIDTH = 800; // Larghezza dello spazio di gioco
    private static final int HEIGHT = 600; // Altezza dello spazio di gioco
    private static final int OBSTACLE_SIZE = 40; // Dimensione degli ostacoli
    private static final int OBSTACLE_SPEED = 5; // Velocità con cui gli ostacoli che si muovono
    private static final int SCALED_WIDTH = 35; // Larghezza ridimensionata dell'immagine degli ostacoli
    private static final int SCALED_HEIGHT = 35; // Altezza ridimensionata dell'immagine degli ostacoli

    private ArrayList<Rectangle> obstacles = new ArrayList<>(); // Lista per memorizzare i rettangoli degli ostacoli
    private ArrayList<ImageIcon> obstacleIcons = new ArrayList<>(); // Lista per memorizzare le icone degli ostacoli
    private Semaphore mutex = new Semaphore(1); // Semaforo per la mutua esclusione

    /**
     * Costruisce un oggetto SpaceModel.
     */
    public SpaceModel() {}

    /**
     * Restituisce la lista dei rettangoli degli ostacoli.
     * 
     * @return ArrayList dei rettangoli degli ostacoli
     */
    public ArrayList<Rectangle> getObstacles() {
        return obstacles;
    }

    /**
     * Restituisce la lista delle icone degli ostacoli.
     * 
     * @return ArrayList delle icone degli ostacoli
     */
    public ArrayList<ImageIcon> getObstacleIcons() {
        return obstacleIcons;
    }

    /**
     * Restituisce il semaforo mutex.
     * 
     * @return Semaforo per l'esclusione mutua
     */
    public Semaphore getMutex() {
        return mutex;
    }

    /**
     * Aggiorna le posizioni degli ostacoli e aggiunge nuovi ostacoli casualmente.
     */
    public void updateObstacles() {
        for (int i = 0; i < obstacles.size(); i++) {
            Rectangle obstacle = obstacles.get(i);
            obstacle.y += OBSTACLE_SPEED;
            if (obstacle.y > HEIGHT) {
                obstacles.remove(obstacle);
                obstacleIcons.remove(i);
                i--;
            }
        }
        // Aggiunge un nuovo ostacolo con una certa probabilità
        if (Math.random() < 0.06) {
            int obstacleX = new Random().nextInt(WIDTH - OBSTACLE_SIZE);
            obstacles.add(new Rectangle(obstacleX, 0, OBSTACLE_SIZE, OBSTACLE_SIZE));

            // Carica l'immagine degli ostacoli
            ImageIcon originalIcon = new ImageIcon(getClass().getResource("/view/ostacolo.png"));

            // Ridimensiona l'immagine
            Image scaledImage = originalIcon.getImage().getScaledInstance(SCALED_WIDTH, SCALED_HEIGHT, Image.SCALE_SMOOTH);

            // Crea un nuovo ImageIcon con l'immagine ridimensionata
            ImageIcon scaledIcon = new ImageIcon(scaledImage);

            // Aggiunge l'immagine ridimensionata alla lista obstacleIcons
            obstacleIcons.add(scaledIcon);
        }
    }
}
