package Main;

import Model.SpaceModel;
import control.Controller;
import view.Finestra;

/**
 * La classe Main avvia il gioco spaziale.
 * @author Candoni Zanatta Bergamo
 */
public class Main {
	/**
	 * Avvia il gioco spaziale.
	 * @version 17.0.8.1+1
	 * @param args Gli argomenti della riga di comando.
	 */
    public static void main(String[] args) {
        SpaceModel model = new SpaceModel(); // Crea il modello del gioco
        Finestra f = new Finestra(); // Crea la finestra di gioco
        Controller control = new Controller(model, f.getPannello()); // Crea il controller e associa modello e vista

        f.getPannello().setPlayerPosition(400, 500); // Imposta la posizione iniziale del giocatore

        // Avvia un thread per gestire il gioco
        Runnable runn = new Runnable() {

			@Override
			public void run() {
				while (true) {
	                try {
	                    model.getMutex().acquire(); // Acquisisce il semaforo per l'accesso al modello in modo sincronizzato
	                    model.updateObstacles(); // Aggiorna gli ostacoli nel modello
	                    model.getMutex().release(); // Rilascia il semaforo

	                    // Aggiorna la posizione del giocatore e degli ostacoli nella vista
	                    f.getPannello().setPlayerPosition(f.getPannello().getPlayerX(), f.getPannello().getPlayerY());
	                    f.getPannello().setObstacles(model.getObstacles(), model.getObstacleIcons());
	                    f.getPannello().repaint(); // Ridisegna la vista

	                    Thread.sleep(10); // Mette in pausa il thread per 10 millisecondi
	                } catch (InterruptedException e) {
	                    e.printStackTrace(); // Gestione dell'eccezione in caso di interruzione del thread
				
			}
        	
        }
        
	}
};

    Thread tt = new Thread(runn);
    tt.start();
    

    }}